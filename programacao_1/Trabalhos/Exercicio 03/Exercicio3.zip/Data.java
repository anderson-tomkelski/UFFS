class Data{
	int dia, mes, ano;

	public String formata(){
		return this.dia + "/" + this.mes + "/" + this.ano;
	}
}
